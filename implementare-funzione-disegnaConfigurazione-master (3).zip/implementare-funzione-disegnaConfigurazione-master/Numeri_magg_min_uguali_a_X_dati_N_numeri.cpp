#include <iostream>

using namespace std;

main()
{
    int N;
    int numero;
    int X;
    int n_max=0;
    int n_min=0;
    int n_ug=0;

    cout<<"inserire quanti numeri interi vuoi digitare"<<endl;
    cin>>N;
    
      cout<<"scrivi numero intero"<<endl;
      cin>>X;

    int i;
    for(i=0;i<N;i++)
    {
        cout<<"scrivi numero intero "<<endl;
        cin>>numero;
        if(numero>X)
          {
            n_max++;}
        
         if(numero<X)
           {
            n_min++;}
       
          if(numero==X)
            {
            n_ug++;}
    }
  
    cout<<"I numeri  maggiori di "<<X<<" sono "<<n_max<<endl;
    cout<<"I numeri  minori di "<<X<<" sono "<<n_min<<endl;
    cout<<"I numeri  uguali a "<<X<<" sono "<<n_ug<<






}
