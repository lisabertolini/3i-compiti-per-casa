#include <iostream>

using namespace std;

main()
{

int i;
int num_max;

cout<<"inserire quanti numeri pari vuoi vedere"<<endl;
cin>>num_max;

cout<<"ecco i primi "<<num_max<<" numeri pari:"<<endl;

    for(i=0;i<num_max;i+=2)
    {cout<<i<<;}
}
