# implementare-funzione-disegnaconfigurazione
Repository per svolgere l'esercizio di scrivere la funzione disegnaconfigurazione()
