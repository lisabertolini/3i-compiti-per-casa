#include <iostream>

using namespace std;

main()
{

int num_max=100;
int i;

for(i=0;i<=num_max;i+=2)
{cout<<"i primi 100 numeri pari sono:"<<i<<endl;}
}
