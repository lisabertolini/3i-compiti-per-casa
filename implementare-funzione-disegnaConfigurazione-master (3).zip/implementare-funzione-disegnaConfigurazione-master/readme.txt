utilizzo di sole variabili globali
utilizzo di sole funzioni senza parametri con tipo ritorno void
manca implementazione di eseguiAzione()