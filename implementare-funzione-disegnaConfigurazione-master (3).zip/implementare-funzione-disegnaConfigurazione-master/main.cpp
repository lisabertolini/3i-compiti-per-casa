//
//  Created by Alberto Carraro on 27/09/16.
//  Copyright (c) 2016 Alberto Carraro. All rights reserved.
//

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <cstdlib>
#include <iostream>

using namespace std;

/******************** VARIABILI GLOBALI E TIPI DI DATO ********************/

// variabili per memorizzare la configurazione attuale della scena
unsigned char missionari_sx;
unsigned char missionari_dx;
// numero di missionari presenti su ciascuna sponda
// assumono valori tra 0 e 3

unsigned char cannibali_sx;
unsigned char cannibali_dx;
// numero di cannibali presenti su ciascuna sponda
// assumono valori tra 0 e 3

unsigned char missionari_barca;
unsigned char cannibali_barca;
// assumono valori da 0 a 2 e la loro somma e' <= 2

char lato_barca;
// assume solo due valori: 'd' e 's'

// variabili per memorizzare le scelte dell'utente quando decide la mossa da fare
char elemento;
char partenza;
char arrivo;

// variabili per controllare la terminazione del gioco
bool gioco_terminato;
bool vittoria;
bool sconfitta;

/******************** PROTOTIPI DELLE FUNZIONI AUSILIARIE ********************/
void disegnaConfigurazione();
void controllaVittoria();
void controllaSconfitta();
void inizializza();
void interazioneUtente();
void eseguiAzione();
void messaggioFinale();

/***** FUNZIONE PRINCIPALE *******************************/
int main(){
    inizializza();
    while(!gioco_terminato){
        disegnaConfigurazione();
        interazioneUtente();
        eseguiAzione();
        controllaVittoria();
        controllaSconfitta();
        gioco_terminato = vittoria || sconfitta;
    }
    messaggioFinale();
    return 0;
}


/******************** IMPLEMENTAZIONE DELLE FUNZIONI AUSILIARIE ********************/
/*
Questa funzione modifica le variabili globali che controllano la terminazione del gioco.
Direttamente:
    vittoria
 */
void controllaVittoria(){
    vittoria = (missionari_sx == 3 && cannibali_sx == 3);
}

/*
Questa funzione modifica le variabili globali che controllano la terminazione del gioco.
Direttamente:
    sconfitta
 */
void controllaSconfitta(){
    sconfitta = (
                (missionari_sx < cannibali_sx && missionari_sx > 0) ||
                (missionari_dx < cannibali_dx && missionari_dx > 0)
                );
}

/*
 Questa funzione scrive sulla console il messaggio finale del gioco.
 Non ha effetti su alcuna variabile globale.
 */
void messaggioFinale(){
    if (vittoria)
        cout << "\n Hai vinto." << endl;
    if (sconfitta)
        cout << "\n Hai perso." << endl;
}

/*
Questa funzione disegna sulla console la confugurazione attuale degli elementi del gioco.
Non ha effetti su alcuna variabile globale.
*/

void disegnaConfigurazione(){
    
    /* 
     qui inserire il codice che scrive le lettere 'm' e 'c' sopra la sponda sinistra
     per segnalare la presenza di missionari e cannibali su tale sponda, nel numero corretto 
     come indicato dai valori delle variabili globali
     Hint: usare il ciclo for per stampare le lettere 'm' e 'c'
     */
    
    for (int i = 1; i <= 3; i++){
        /* qui dentro utilizzare le istruzioni 
         cout << "m";
         cout << " ";
         ma stando attenti a stampare missionari_sx volte 'm'
         e 3-missionari_sx volte lo spazio
        */
    }
    
    /* 
     qui inserire il codice che scrive le lettere 'm' e 'c' sopra la sponda destra
     per segnalare la presenza di missionari e cannibali su tale sponda, nel numero corretto 
     come indicato dai valori delle variabili globali
     Hint: usare il ciclo for per stampare le lettere 'm' e 'c'
     */

    cout << "\n";
    char posto_sx = '_';
    char posto_dx = '_';
    
    // due missionari occupano entrambi i posti in barca
    if (missionari_barca == 2)
        posto_dx = 'm';
    else {
        if (cannibali_barca == 2)   // due cannibali occupano entrambi i posti in barca
            posto_sx = 'c';
        else {
            // i missionari cominciano ad occupare i posti in barca a partire da sinistra
            if (missionari_barca >= 1)
                posto_sx = 'm';
            // i cannibali cominciano ad occupare i posti in barca a partire da destra
            if (cannibali_barca >= 1)
                posto_dx = 'c';
        }
    }

    if (lato_barca == 's')
        cout << "------------_|" << posto_sx << "." << posto_dx << "|__________ ------------" << endl;
    if (lato_barca == 'd')
        cout << "------------__________|" << posto_sx << "." << posto_dx << "|_ ------------" << endl;
    cout << "\n";
}

/*
 Questa funzione imposta i valori delle variabili globali.
 Direttamente:
    missionari_sx, cannibali_sx, missionari_dx, cannibali_dx, missionari_barca, cannibali_barca, lato_barca
 Indirettamente:
    vittoria, sconfitta, gioco_terminato
 */
void inizializza(){
    missionari_sx = 1;
    cannibali_sx = 1;
    missionari_dx = 1;
    cannibali_dx = 1;
    missionari_barca = 1;
    cannibali_barca = 1;
    lato_barca = 'd';
    // invochiamo le funzioni che impostano i valori delle variabili sconfitta, vittoria
    controllaVittoria();
    controllaSconfitta();
    gioco_terminato = vittoria || sconfitta;
}

/*
 Questa funzione imposta i valori delle variabili globali.
 Direttamente:
    elemento, azione, arrivo
 riempiendole con i valori digitati dall'utente
 Attenzione: quando elemento == 'b' i valori di azione e arrivo devono essere considerati inattendibili e quindi non utilizzati
 Non sono ancora implementati i controlli per la coerenza dell'azione della mossa indicata dall'utente
 */
void interazioneUtente(){
    bool errore_inserimento = false;
    
    do{
        if (errore_inserimento)
            cout << "Errore: hai premuto il tasto " << elemento << endl;
        cout << "Quale elemento vuoi muovere? (m/c/b):" << endl;
        cout << " 'm' per missionario" << endl;
        cout << " 'c' per cannibale" << endl;
        cout << " 'b' per barca" << endl;
        cin >> elemento;
        errore_inserimento = (elemento != 'm' && elemento != 'c' && elemento != 'b');
    }while(errore_inserimento);
    
    // se l'utente ha scelto la barca, non c'è dubbio sull'azione che essa dovrà compiere
    if (elemento == 'm' || elemento != 'c'){
        errore_inserimento = false;
        do{
            if (errore_inserimento)
                cout << "Errore: hai premuto il tasto " << partenza << endl;
            cout << "Dove si trova l'elemento scelto?" << endl;
            cout << " 's' per sponda sinistra" << endl;
            cout << " 'd' per sponda destra" << endl;
            cout << " 'b' per barca" << endl;
            cin >> partenza;
            errore_inserimento = (partenza != 's' && partenza != 'd' && partenza != 'b');
        }while(errore_inserimento);
        
        errore_inserimento = false;
        do{
            if (errore_inserimento)
                cout << "Errore: hai premuto il tasto " << arrivo << endl;
            cout << "Dove lo vuoi muovere? (s/b/d):" << endl;
            cout << " 's' per sponda sinistra" << endl;
            cout << " 'd' per sponda destra" << endl;
            cout << " 'b' per barca" << endl;
            cin >> arrivo;
            errore_inserimento = (arrivo != 's' && arrivo != 'd' && arrivo != 'b');
        }while(errore_inserimento);
    }
    // qui inserire i controlli di validità della mossa
    // se la mossa risulta insensata bisogna richiedere all'utente di inserire i
    // tre valori che identificano la sua mossa
}

/*
Questa funzione imposta i valori delle variabili globali.
Direttamente:
    missionari_sx, cannibali_sx, missionari_dx, cannibali_dx, missionari_barca, cannibali_barca, lato_barca
In base all'azione identificata dalla terna di valori (elemento, azione, arrivo)
Se nella funzione "void interazioneUtente()" non vengono implementati i controlli sulla validità della mossa,
 questi controlli vanno implementati in questa funzione.
*/
void eseguiAzione(){
    // Qui inserire codice che applica la mossa alla configurazione corrente
}

